import joblib
from xgboost import XGBClassifier
from sklearn.linear_model import LogisticRegression
from data_loader import load_data
from preprocessing import preprocess

def train():
    df = load_data()
    X_train, X_test, y_train, y_test, scaler = preprocess(df)
    
    # Train XGBoost
    model = XGBClassifier(n_estimators=100, max_depth=5, learning_rate=0.1)
    model.fit(X_train, y_train)
    
    # Save models
    joblib.dump(model, 'models/xgboost_model.pkl')
    joblib.dump(scaler, 'models/scaler.pkl')
    print("Models trained and saved successfully.")

if __name__ == "__main__":
    train()
