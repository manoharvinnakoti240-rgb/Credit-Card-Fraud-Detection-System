import pandas as pd
import numpy as np

def load_data(path='data/creditcard.csv'):
    try:
        return pd.read_csv(path)
    except FileNotFoundError:
        print("Dataset not found. Generating dummy data for demonstration...")
        return generate_dummy_data()

def generate_dummy_data():
    np.random.seed(42)
    data = pd.DataFrame(np.random.randn(1000, 30), columns=[f'V{i}' for i in range(1, 29)] + ['Time', 'Amount'])
    data['Class'] = np.random.choice([0, 1], size=1000, p=[0.98, 0.02])
    data.to_csv('data/creditcard.csv', index=False)
    return data
