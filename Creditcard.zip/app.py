import streamlit as st
import pandas as pd
import joblib
import numpy as np

st.set_page_config(page_title="Fraud Detector", page_icon="💳")
st.title("💳 Credit Card Fraud Detection")
st.subheader("Developed by Manohar & Prem")

try:
    model = joblib.load('models/xgboost_model.pkl')
    scaler = joblib.load('models/scaler.pkl')
except:
    st.error("Model files not found! Please run 'python src/trainer.py' first.")
    st.stop()

st.sidebar.header("Input Transaction Data")
def user_input():
    v_feats = {f'V{i}': st.sidebar.slider(f'V{i}', -5.0, 5.0, 0.0) for i in range(1, 29)}
    time = st.sidebar.number_input("Time", value=0.0)
    amount = st.sidebar.number_input("Amount", value=1.0)
    data = {**v_feats, 'Time': time, 'Amount': amount}
    return pd.DataFrame(data, index=[0])

input_df = user_input()

if st.button("Predict Fraud"):
    # Preprocessing
    input_df[['Time', 'Amount']] = scaler.transform(input_df[['Time', 'Amount']])
    prediction = model.predict(input_df)
    prob = model.predict_proba(input_df)[0][1]
    
    if prediction[0] == 1:
        st.error(f"🚨 FRAUD DETECTED! Probability: {prob:.2%}")
    else:
        st.success(f"✅ Transaction Legitimate. Probability of Fraud: {prob:.2%}")
