# Credit Card Fraud Detection System
Developed by **Manohar & Prem**

## Problem Statement
Detecting fraudulent credit card transactions is crucial for financial institutions. This project uses Machine Learning (XGBoost, Isolation Forest) to identify anomalies and fraudulent patterns in highly imbalanced datasets.

## Features
- **SMOTE**: Handling class imbalance.
- **Robust Scaling**: Handling outliers in Time and Amount.
- **Hybrid Modeling**: Comparison between XGBoost (Supervised) and Isolation Forest (Unsupervised).
- **Streamlit App**: Interactive dashboard for real-time prediction.

## How to Run
1. Install dependencies: `pip install -r requirements.txt`
2. Run the training script: `python src/trainer.py`
3. Launch the app: `streamlit run app.py`
